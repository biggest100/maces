function About() {
  return (
    <div>
      <h1>This is my About Component</h1>
    </div>
  );
}

export const Services = () => {
  return (
    <>
      <h3>This is my Service Component</h3>
    </>
  );
};

export default About;
