export const myStyle = {
  color: "white",
  fontSize: 20,
  backgroundColor: "forestgreen",
};

export const anotherStyle = {
  color: "orange",
  backgroundColor: "green",
  fontSize: 40,
};
