import "./contact.css";

function Contact() {
  return (
    <div>
      <h1 className="h1">Contact us page</h1>
    </div>
  );
}

export default Contact;
