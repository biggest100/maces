function NewCar({ carName, carBrand }) {
  return (
    <div>
      <h1>
        This is my New Car which is {carName} its brand is {carBrand}
      </h1>
    </div>
  );
}

export default NewCar;
