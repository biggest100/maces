import FirstHeade from "../Headers/FirstHeade";

function Layout() {
  return (
    <div className="wrapper">
      <FirstHeade />
    </div>
  );
}

export default Layout;
