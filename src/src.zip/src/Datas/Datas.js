export const Users = [
  { id: 1, name: "Osas", email: "Osas@mail.com" },
  { id: 2, name: "sas", email: "sas@mail.com" },
  { id: 3, name: "vinx", email: "vinx@mail.com" },
  { id: 4, name: "dessy", email: "dessy@mail.com" },
];
